<?php
session_start();

require __DIR__ . '/front/html/register.html';


